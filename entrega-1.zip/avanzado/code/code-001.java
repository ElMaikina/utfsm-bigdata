public static class TokenizerMapper
    extends Mapper<Object, Text, Text, IntWritable> {  
  public void map(Object key, Text value, Context context)
      throws IOException, InterruptedException {
    // Code
  }
}